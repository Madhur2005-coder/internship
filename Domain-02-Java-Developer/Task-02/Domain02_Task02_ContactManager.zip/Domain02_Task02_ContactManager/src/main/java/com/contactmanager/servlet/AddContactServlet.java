package com.contactmanager.servlet;

import com.contactmanager.model.Contact;
import com.contactmanager.util.ContactValidator;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * AddContactServlet.java
 *
 * Handles:
 *   POST /contacts  → validate & persist a new contact
 *
 * On success  → redirect to /contacts  (PRG pattern prevents duplicate submissions)
 * On failure  → forward back to contact-form.jsp with field errors + preserved input
 */
@WebServlet("/contacts/save")
public class AddContactServlet extends HttpServlet {

    /** Thread-safe auto-increment ID counter. */
    private static final AtomicInteger ID_COUNTER = new AtomicInteger(1);

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        // ── 1. Read form parameters ──────────────────────────────
        String name  = request.getParameter("name");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");

        // ── 2. Validate ──────────────────────────────────────────
        Map<String, String> errors = ContactValidator.validate(name, email, phone);

        if (!errors.isEmpty()) {
            // Re-forward to the form; preserve what the user typed
            request.setAttribute("errors",    errors);
            request.setAttribute("prevName",  ContactValidator.sanitise(name));
            request.setAttribute("prevEmail", ContactValidator.sanitise(email));
            request.setAttribute("prevPhone", ContactValidator.sanitise(phone));
            request.getRequestDispatcher("/WEB-INF/contact-form.jsp")
                   .forward(request, response);
            return;
        }

        // ── 3. Build Contact object ──────────────────────────────
        Contact contact = new Contact(
                ID_COUNTER.getAndIncrement(),
                ContactValidator.sanitise(name),
                ContactValidator.sanitise(email),
                ContactValidator.sanitise(phone)
        );

        // ── 4. Add to session list (in-memory store) ─────────────
        HttpSession session = request.getSession(true);

        @SuppressWarnings("unchecked")
        List<Contact> contacts = (List<Contact>) session.getAttribute("contacts");

        if (contacts == null) {
            contacts = new ArrayList<>();
            session.setAttribute("contacts", contacts);
        }

        contacts.add(contact);

        // ── 5. PRG redirect → prevents duplicate on browser refresh
        response.sendRedirect(request.getContextPath() + "/contacts?success=true");
    }
}
