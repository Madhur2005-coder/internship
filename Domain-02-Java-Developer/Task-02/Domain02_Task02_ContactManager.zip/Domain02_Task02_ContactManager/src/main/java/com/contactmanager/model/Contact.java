package com.contactmanager.model;

/**
 * Contact.java — JavaBean representing one contact entry.
 * Fields : id, name, email, phone
 */
public class Contact {

    private int    id;
    private String name;
    private String email;
    private String phone;

    // ── Constructors ────────────────────────────────────────────
    public Contact() {}

    public Contact(int id, String name, String email, String phone) {
        this.id    = id;
        this.name  = name;
        this.email = email;
        this.phone = phone;
    }

    // ── Getters & Setters ────────────────────────────────────────
    public int    getId()    { return id; }
    public String getName()  { return name; }
    public String getEmail() { return email; }
    public String getPhone() { return phone; }

    public void setId(int id)       { this.id    = id; }
    public void setName(String n)   { this.name  = n; }
    public void setEmail(String e)  { this.email = e; }
    public void setPhone(String p)  { this.phone = p; }

    @Override
    public String toString() {
        return "Contact{id=" + id + ", name='" + name + "', email='" + email + "', phone='" + phone + "'}";
    }
}
