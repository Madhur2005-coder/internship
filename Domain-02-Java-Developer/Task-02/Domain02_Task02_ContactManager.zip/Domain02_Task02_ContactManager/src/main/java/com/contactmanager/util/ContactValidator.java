package com.contactmanager.util;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * ContactValidator.java
 * Centralises all server-side validation rules for a Contact form.
 *
 * Rules:
 *   Name  — required, 2–50 characters
 *   Email — required, must match standard email pattern
 *   Phone — optional; if supplied must be exactly 10 digits
 */
public class ContactValidator {

    // ── Compiled patterns (compiled once, reused) ───────────────
    private static final Pattern EMAIL_PATTERN =
            Pattern.compile("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");

    private static final Pattern PHONE_PATTERN =
            Pattern.compile("^\\d{10}$");

    /**
     * Validates form parameters and returns a map of field → error message.
     * An empty map means the input is valid.
     *
     * @param name  raw name value from request
     * @param email raw email value from request
     * @param phone raw phone value from request (may be null / empty)
     * @return map of field names to error messages
     */
    public static Map<String, String> validate(String name, String email, String phone) {
        Map<String, String> errors = new HashMap<>();

        // ── Name validation ──────────────────────────────────────
        if (name == null || name.trim().isEmpty()) {
            errors.put("name", "Please enter a valid name");
        } else if (name.trim().length() < 2 || name.trim().length() > 50) {
            errors.put("name", "Name must be between 2 and 50 characters");
        }

        // ── Email validation ─────────────────────────────────────
        if (email == null || email.trim().isEmpty()) {
            errors.put("email", "Email address is required");
        } else if (!EMAIL_PATTERN.matcher(email.trim()).matches()) {
            errors.put("email", "Invalid email address");
        }

        // ── Phone validation (optional field) ────────────────────
        if (phone != null && !phone.trim().isEmpty()) {
            if (!PHONE_PATTERN.matcher(phone.trim()).matches()) {
                errors.put("phone", "Use 10-digit format (digits only)");
            }
        }

        return errors;
    }

    /** Sanitise a string to prevent XSS — escapes HTML special chars. */
    public static String sanitise(String input) {
        if (input == null) return "";
        return input.trim()
                    .replace("&",  "&amp;")
                    .replace("<",  "&lt;")
                    .replace(">",  "&gt;")
                    .replace("\"", "&quot;")
                    .replace("'",  "&#x27;");
    }
}
