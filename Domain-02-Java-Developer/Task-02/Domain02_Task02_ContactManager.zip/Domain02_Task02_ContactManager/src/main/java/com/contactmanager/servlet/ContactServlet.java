package com.contactmanager.servlet;

import com.contactmanager.model.Contact;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * ContactServlet.java
 *
 * Handles two GET routes:
 *   GET /contacts      → display all contacts  (contact-list.jsp)
 *   GET /contacts/add  → show blank add-form   (contact-form.jsp)
 *
 * Contact list is stored in the HTTP Session so it persists across requests
 * (in-memory; no database required for Task 2).
 */
@WebServlet(urlPatterns = {"/contacts", "/contacts/add"})
public class ContactServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String path = request.getServletPath();           // "/contacts" or "/contacts/add"

        if ("/contacts/add".equals(path)) {
            // ── Show the blank contact form ──────────────────────
            request.getRequestDispatcher("/WEB-INF/contact-form.jsp")
                   .forward(request, response);

        } else {
            // ── Show contact list ────────────────────────────────
            HttpSession session = request.getSession(true);

            @SuppressWarnings("unchecked")
            List<Contact> contacts = (List<Contact>) session.getAttribute("contacts");

            if (contacts == null) {
                contacts = new ArrayList<>();
                session.setAttribute("contacts", contacts);
            }

            // Optional search/filter
            String query = request.getParameter("q");
            List<Contact> filtered = contacts;

            if (query != null && !query.trim().isEmpty()) {
                String q = query.trim().toLowerCase();
                filtered = contacts.stream()
                        .filter(c -> c.getName().toLowerCase().contains(q)
                                  || c.getEmail().toLowerCase().contains(q))
                        .collect(java.util.stream.Collectors.toList());
                request.setAttribute("searchQuery", query);
            }

            request.setAttribute("contacts", filtered);
            request.setAttribute("totalCount", contacts.size());
            request.getRequestDispatcher("/WEB-INF/contact-list.jsp")
                   .forward(request, response);
        }
    }
}
