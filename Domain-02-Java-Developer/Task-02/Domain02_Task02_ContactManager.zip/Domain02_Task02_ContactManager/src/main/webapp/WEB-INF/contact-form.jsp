<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Contact</title>
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Segoe UI', Tahoma, sans-serif; background: #f0f2f5; color: #333; min-height: 100vh; }

        .navbar { background: #2c3e50; color: #fff; padding: 1rem 2rem;
                  display: flex; align-items: center; justify-content: space-between; }
        .navbar h1 { font-size: 1.3rem; }
        .back-link { color: #aac4e0; text-decoration: none; font-size: 0.9rem; }
        .back-link:hover { color: #fff; }

        .container { max-width: 520px; margin: 2.5rem auto; padding: 0 1rem; }

        /* ── Card ───────────────────────────────────────────────── */
        .card { background: #fff; border-radius: 12px;
                box-shadow: 0 2px 16px rgba(0,0,0,.1); padding: 2rem; }
        .card h2 { font-size: 1.25rem; margin-bottom: 1.5rem; color: #2c3e50; }

        /* ── Form fields ────────────────────────────────────────── */
        .form-group { margin-bottom: 1.25rem; }
        label { display: block; font-size: 0.88rem; font-weight: 600;
                margin-bottom: 0.4rem; color: #555; }
        label .required { color: #e74c3c; margin-left: 2px; }
        input[type="text"],
        input[type="email"],
        input[type="tel"] {
            width: 100%; padding: 0.65rem 0.9rem;
            border: 1.5px solid #ccc; border-radius: 7px;
            font-size: 0.95rem; transition: border-color 0.2s, box-shadow 0.2s;
        }
        input:focus { outline: none; border-color: #2980b9;
                      box-shadow: 0 0 0 3px rgba(41,128,185,.15); }
        input.is-invalid { border-color: #e74c3c; background: #fff8f8; }
        input.is-invalid:focus { box-shadow: 0 0 0 3px rgba(231,76,60,.15); }

        /* ── Error messages ─────────────────────────────────────── */
        .field-error { font-size: 0.82rem; color: #e74c3c; margin-top: 0.35rem;
                       display: flex; align-items: center; gap: 0.3rem; }

        /* ── Submit button ──────────────────────────────────────── */
        .btn-submit { width: 100%; padding: 0.75rem; background: #2980b9; color: #fff;
                      border: none; border-radius: 7px; font-size: 1rem; font-weight: 600;
                      cursor: pointer; transition: background 0.2s; position: relative; }
        .btn-submit:hover { background: #1f6fa0; }
        .btn-submit:disabled { background: #90b8d8; cursor: not-allowed; }

        /* ── Spinner (shown during submit) ─────────────────────── */
        .spinner { display: none; width: 18px; height: 18px; border: 3px solid rgba(255,255,255,.4);
                   border-top-color: #fff; border-radius: 50%;
                   animation: spin 0.7s linear infinite;
                   position: absolute; right: 1rem; top: 50%; transform: translateY(-50%); }
        @keyframes spin { to { transform: translateY(-50%) rotate(360deg); } }

        .hint { font-size: 0.8rem; color: #999; margin-top: 0.3rem; }
    </style>
</head>
<body>

<nav class="navbar">
    <h1>📋 Contact Manager</h1>
    <a class="back-link" href="${pageContext.request.contextPath}/contacts">← Back to Contacts</a>
</nav>

<div class="container">
    <div class="card">
        <h2>Add New Contact</h2>

        <form id="contactForm"
              method="post"
              action="${pageContext.request.contextPath}/contacts/save"
              novalidate>

            <%-- ── Name ──────────────────────────────────────────── --%>
            <div class="form-group">
                <label for="name">Full Name <span class="required">*</span></label>
                <input type="text" id="name" name="name"
                       value="<c:out value='${prevName}'/>"
                       class="${not empty errors.name ? 'is-invalid' : ''}"
                       placeholder="e.g. Madhur Sharma"
                       maxlength="50" autocomplete="off">
                <c:if test="${not empty errors.name}">
                    <div class="field-error">⚠ ${errors.name}</div>
                </c:if>
            </div>

            <%-- ── Email ─────────────────────────────────────────── --%>
            <div class="form-group">
                <label for="email">Email Address <span class="required">*</span></label>
                <input type="email" id="email" name="email"
                       value="<c:out value='${prevEmail}'/>"
                       class="${not empty errors.email ? 'is-invalid' : ''}"
                       placeholder="e.g. madhur@example.com"
                       autocomplete="off">
                <c:if test="${not empty errors.email}">
                    <div class="field-error">⚠ ${errors.email}</div>
                </c:if>
            </div>

            <%-- ── Phone ─────────────────────────────────────────── --%>
            <div class="form-group">
                <label for="phone">Phone Number</label>
                <input type="tel" id="phone" name="phone"
                       value="<c:out value='${prevPhone}'/>"
                       class="${not empty errors.phone ? 'is-invalid' : ''}"
                       placeholder="10-digit number (optional)"
                       maxlength="10" autocomplete="off">
                <c:if test="${not empty errors.phone}">
                    <div class="field-error">⚠ ${errors.phone}</div>
                </c:if>
                <p class="hint">Optional — digits only, no spaces or dashes.</p>
            </div>

            <%-- ── Submit ─────────────────────────────────────────── --%>
            <button type="submit" class="btn-submit" id="submitBtn">
                Save Contact
                <span class="spinner" id="spinner"></span>
            </button>

        </form>
    </div>
</div>

<%-- ── Client-side: auto-focus first error, spinner on submit ───── --%>
<script>
    // Auto-focus the first invalid field (if server returned errors)
    const firstInvalid = document.querySelector('input.is-invalid');
    if (firstInvalid) firstInvalid.focus();

    // Show spinner + disable button while form is submitting
    document.getElementById('contactForm').addEventListener('submit', function () {
        const btn     = document.getElementById('submitBtn');
        const spinner = document.getElementById('spinner');
        btn.disabled        = true;
        spinner.style.display = 'block';
    });

    // Real-time: remove is-invalid styling once the user starts correcting
    document.querySelectorAll('input.is-invalid').forEach(function (input) {
        input.addEventListener('input', function () {
            this.classList.remove('is-invalid');
            const errDiv = this.closest('.form-group').querySelector('.field-error');
            if (errDiv) errDiv.style.display = 'none';
        });
    });
</script>

</body>
</html>
