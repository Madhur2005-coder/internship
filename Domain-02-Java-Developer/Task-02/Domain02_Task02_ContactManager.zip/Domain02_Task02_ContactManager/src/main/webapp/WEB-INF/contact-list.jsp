<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core"      prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/functions" prefix="fn" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Manager</title>
    <style>
        /* ── Reset & base ───────────────────────────────────────── */
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Segoe UI', Tahoma, sans-serif; background: #f0f2f5; color: #333; }

        /* ── Navbar ─────────────────────────────────────────────── */
        .navbar { background: #2c3e50; color: #fff; padding: 1rem 2rem;
                  display: flex; align-items: center; justify-content: space-between; }
        .navbar h1 { font-size: 1.3rem; letter-spacing: 0.5px; }
        .navbar span { font-size: 0.85rem; opacity: 0.7; }

        /* ── Container ──────────────────────────────────────────── */
        .container { max-width: 960px; margin: 2rem auto; padding: 0 1rem; }

        /* ── Toast notification ─────────────────────────────────── */
        .toast { background: #27ae60; color: #fff; padding: 0.75rem 1.25rem;
                 border-radius: 6px; margin-bottom: 1.5rem;
                 display: flex; align-items: center; gap: 0.5rem; font-size: 0.95rem; }

        /* ── Toolbar ────────────────────────────────────────────── */
        .toolbar { display: flex; gap: 1rem; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap; }
        .search-box { flex: 1; min-width: 200px; padding: 0.6rem 1rem;
                      border: 1px solid #ccc; border-radius: 6px; font-size: 0.95rem; }
        .search-box:focus { outline: none; border-color: #2980b9; box-shadow: 0 0 0 3px rgba(41,128,185,.15); }
        .btn-count { font-size: 0.85rem; color: #666; white-space: nowrap; }

        /* ── Table ──────────────────────────────────────────────── */
        .card { background: #fff; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,.08); overflow: hidden; }
        table { width: 100%; border-collapse: collapse; }
        thead { background: #2c3e50; color: #fff; }
        thead th { padding: 0.85rem 1rem; text-align: left; font-weight: 500; font-size: 0.9rem; }
        tbody tr { border-bottom: 1px solid #f0f0f0; transition: background 0.15s; }
        tbody tr:hover { background: #f7faff; }
        tbody tr:last-child { border-bottom: none; }
        td { padding: 0.8rem 1rem; font-size: 0.92rem; }
        .badge-id { background: #eaf0fb; color: #2980b9; border-radius: 4px;
                    padding: 2px 8px; font-size: 0.8rem; font-weight: 600; }

        /* ── Empty state ─────────────────────────────────────────── */
        .empty-state { text-align: center; padding: 3rem 1rem; color: #888; }
        .empty-state .icon { font-size: 3rem; margin-bottom: 0.75rem; }
        .empty-state p { font-size: 1rem; }

        /* ── FAB (Floating Add Button) ───────────────────────────── */
        .fab { position: fixed; bottom: 2rem; right: 2rem;
               background: #2980b9; color: #fff; border: none; border-radius: 50px;
               padding: 0.8rem 1.5rem; font-size: 1rem; font-weight: 600;
               cursor: pointer; box-shadow: 0 4px 14px rgba(41,128,185,.4);
               text-decoration: none; display: flex; align-items: center; gap: 0.4rem;
               transition: background 0.2s, transform 0.15s; }
        .fab:hover { background: #1f6fa0; transform: translateY(-2px); }
    </style>
</head>
<body>

<nav class="navbar">
    <h1>📋 Contact Manager</h1>
    <span>In-Memory Store — Task 2</span>
</nav>

<div class="container">

    <%-- ── Success toast ────────────────────────────────────────── --%>
    <c:if test="${param.success eq 'true'}">
        <div class="toast">✅ Contact added successfully!</div>
    </c:if>

    <%-- ── Toolbar: search + count ──────────────────────────────── --%>
    <div class="toolbar">
        <form method="get" action="${pageContext.request.contextPath}/contacts" style="flex:1;display:flex;gap:0.75rem;">
            <input class="search-box"
                   type="text"
                   name="q"
                   placeholder="Search by name or email…"
                   value="<c:out value='${searchQuery}'/>"
                   autocomplete="off">
            <button type="submit" style="padding:0.6rem 1rem;background:#2c3e50;color:#fff;border:none;border-radius:6px;cursor:pointer;">Search</button>
            <c:if test="${not empty searchQuery}">
                <a href="${pageContext.request.contextPath}/contacts"
                   style="padding:0.6rem 1rem;background:#eee;border-radius:6px;text-decoration:none;color:#333;">Clear</a>
            </c:if>
        </form>
        <span class="btn-count">${totalCount} contact(s) total</span>
    </div>

    <%-- ── Contacts table ────────────────────────────────────────── --%>
    <div class="card">
        <c:choose>
            <c:when test="${empty contacts}">
                <div class="empty-state">
                    <div class="icon">👤</div>
                    <p>No contacts found. Click <strong>+ Add Contact</strong> to get started.</p>
                </div>
            </c:when>
            <c:otherwise>
                <table>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                        </tr>
                    </thead>
                    <tbody>
                        <c:forEach var="contact" items="${contacts}">
                            <tr>
                                <td><span class="badge-id">${contact.id}</span></td>
                                <td><c:out value="${contact.name}"/></td>
                                <td><c:out value="${contact.email}"/></td>
                                <td><c:out value="${not empty contact.phone ? contact.phone : '—'}"/></td>
                            </tr>
                        </c:forEach>
                    </tbody>
                </table>
            </c:otherwise>
        </c:choose>
    </div>

</div>

<%-- ── Floating Add Button ────────────────────────────────────────── --%>
<a class="fab" href="${pageContext.request.contextPath}/contacts/add">
    ＋ Add Contact
</a>

</body>
</html>
