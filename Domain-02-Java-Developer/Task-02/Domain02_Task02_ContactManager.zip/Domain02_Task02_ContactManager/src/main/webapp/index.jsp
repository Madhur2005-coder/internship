<%@ page contentType="text/html;charset=UTF-8" %>
<%-- Redirect root URL to the contacts list --%>
<jsp:forward page="/contacts"/>
