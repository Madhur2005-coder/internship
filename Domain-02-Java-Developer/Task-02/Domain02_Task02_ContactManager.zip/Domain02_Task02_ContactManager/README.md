# Domain 02 — Task 02: Servlet-Based CRUD Application
## Contact Manager Module

---

## Project Structure

```
contact-manager/
├── pom.xml
└── src/main/
    ├── java/com/contactmanager/
    │   ├── model/
    │   │   └── Contact.java            ← JavaBean (id, name, email, phone)
    │   ├── servlet/
    │   │   ├── ContactServlet.java     ← GET /contacts  |  GET /contacts/add
    │   │   └── AddContactServlet.java  ← POST /contacts/save
    │   └── util/
    │       └── ContactValidator.java   ← Server-side validation + XSS sanitiser
    └── webapp/
        ├── index.jsp                   ← Redirects to /contacts
        └── WEB-INF/
            ├── web.xml
            ├── contact-list.jsp        ← Contact table + search
            └── contact-form.jsp        ← Add-contact form with inline errors
```

---

## How to Run

### Prerequisites
- JDK 17+
- Apache Maven 3.8+
- Apache Tomcat 10.1+ (Jakarta EE 10)

### Steps

```bash
# 1. Build the WAR
mvn clean package

# 2. Deploy to Tomcat
#    Copy target/contact-manager.war  →  <TOMCAT_HOME>/webapps/

# 3. Start Tomcat
<TOMCAT_HOME>/bin/startup.sh       # Linux/Mac
<TOMCAT_HOME>\bin\startup.bat      # Windows

# 4. Open in browser
http://localhost:8080/contact-manager/
```

---

## URL Routes

| Method | URL                         | Description              |
|--------|-----------------------------|--------------------------|
| GET    | `/contacts`                 | List all contacts        |
| GET    | `/contacts?q=name`          | Search/filter contacts   |
| GET    | `/contacts/add`             | Show add-contact form    |
| POST   | `/contacts/save`            | Save new contact (PRG)   |

---

## Features Implemented

- **MVC Pattern** — Servlets (Controller) + JSP (View) + JavaBeans (Model)
- **Server-Side Validation** — name (required, 2–50 chars), email (regex), phone (10 digits, optional)
- **XSS Prevention** — all output escaped via `<c:out>` + `ContactValidator.sanitise()`
- **PRG Pattern** — POST → Redirect → GET prevents duplicate submissions on F5
- **Session Storage** — contacts persist across requests (in-memory, no DB needed)
- **Search/Filter** — case-insensitive search by name or email
- **UX Details** — auto-focus first error field, spinner on submit, success toast
